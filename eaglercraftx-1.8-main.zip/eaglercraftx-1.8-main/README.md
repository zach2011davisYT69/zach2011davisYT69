## Dear Mojang,

I am one of the developers of a project that has recently become a large target of your DMCA team, the project in question is "Eaglercraft" which is a series of full HTML5/JavaScript ports of Minecraft Java Edition's source code that run on all major browsers and are fully compatible with all existing Minecraft multiplayer infrastructure.

We (the developers) are not interested in fighting your DMCA complaints, neither are we affiliated with any sites still providing the infringing files, we are simply interested in preserving the project even if that does mean first completely removing every open source copy of the project off of the internet via DMCA.

The game runs smoothly even on low end hardware, like Chromebooks, and we believe your developer team may be interested in taking a look at our code and potentially adopting the source of the project for official use on Minecraft.net as a paid web client once these DMCA complaints are resolved.

We are hoping you can assist us in getting in contact with an active Mojang representative, the Eaglercraft creator's inbox for this specific subject is eagsforum [at] gmail [dot] com if you could forward this contact information and these links to the Java Edition developer team it would be much appreciated.

The goal of eaglercraft was never to pirate the game, it was just to port it to the browser, and the years of time and effort put into the port should not be killed off so violently. we ask that you contact us at the email above to talk things out and figure out a future for eagler. Thank you for reading <3